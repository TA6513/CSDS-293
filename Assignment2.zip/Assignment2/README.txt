not sure what to put here as everything is self explanatory, since I am using VS Code I simply run tests through the test window.

update 9/27/23: added descriptive comments to all matrix classes